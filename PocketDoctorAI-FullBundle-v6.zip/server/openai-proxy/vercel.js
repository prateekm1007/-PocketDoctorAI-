// Vercel handler stub - import the express app
module.exports = require('./index');
