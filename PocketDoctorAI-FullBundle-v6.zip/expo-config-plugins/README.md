Stubs for Google Fit and HealthKit expo config plugins. Implement prebuild changes here.
